const glob = require('glob')
const path = require('path')

function getEntry(pagePath) {
  const entries = {}
  let tmp, emtryName
  glob.sync(pagePath).forEach(function(entry) {
    tmp = entry.split('/').splice(-3)
    emtryName = tmp[1]

    entries[emtryName] = {
      entry: path.join('src', tmp[0], tmp[1], 'index.js'),
      template: path.join('src', tmp[0], tmp[1], 'index.html'),
      filename: emtryName + '.html',
      chunks: ['chunk-vendors', 'chunk-common', 'index', emtryName]
    }
  })
  return entries
}

const pages = getEntry('./src/pages/**?/*.html')

module.exports = {
  publicPath: './',
  // pages,
  // chainWebpack: config => {
  //   config.entry.app = [
  //     './node_modules/babel-polyfill/dist/polyfill.js',
  //     './src/main.js'
  //   ]
  // },
  transpileDependencies: ['nprogress', 'view-design'],
  devServer: {
    compress: true,
    proxy: {
      '/api': {
        target: process.env.VUE_APP_DEV_API_URL,
        bypass: req => {
          const tempMethods = ['POST', 'PUT', 'DELETE', 'GET']
          // 请求则绕过代理
          if (tempMethods.indexOf(req.method) < 0) {
            return process.env.VUE_APP_DEV_API_URL
          }
        },
        pathRewrite: {
          '/api': ''
        }
      }
    }
  },
  css: {
    // 共享全局css变量
    loaderOptions: {
      scss: {
        prependData: `@import "~@/styles/variables.module.scss";`
      },
      less: {
        lessOptions: {
          javascriptEnabled: true
        }
      }
    }
  }
}

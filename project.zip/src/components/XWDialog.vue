<template>
  <Modal
    @on-visible-change="handleHideChange"
    @on-cancel="handleHideChange"
    @on-ok="handleConfirm"
    :value.sync="visible"
    type="confirm"
    :width="width"
    :title="title"
    :footer-hide="isButton"
    :z-index="zindex"
    draggable
    mask-closable
    scrollable
    loading
  >
    <slot />
    <template v-if="isTitle" v-slot:header>
      <slot name="header" />
    </template>
    <template v-if="isButton" v-slot:footer>
      <slot name="fotter" />
    </template>
  </Modal>
</template>

<script>
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    title: String,
    width: {
      type: [Number, String],
      default: 600
    },
    // 是否显示按钮
    isButton: {
      type: Boolean,
      default: false
    },
    // 是否可改变大小
    resize: Boolean,
    // 是否自定义标题
    isTitle: Boolean,
    zindex: Number
  },
  data() {
    return {}
  },
  methods: {
    handleHideChange(v) {
      this.$emit('upadte', v)
    },
    handleConfirm() {
      this.$emit('confirm', false)
    },
    handleCancel() {
      this.$emit('cancel', false)
    }
  }
}
</script>
<style scoped lang="scss">
/deep/ .vxe-modal--content {
  width: 100%;
}
</style>

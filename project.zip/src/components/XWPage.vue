<template>
  <Page
    :total="total"
    size="small"
    :page-size="pageSize"
    show-elevator
    show-sizer
    show-total
    @on-page-size-change="handleSizeChange"
    @on-change="handleCurrentChange"
  />
</template>

<script>
export default {
  name: 'XWPage',
  props: {
    // 是否为分页按钮添加背景色
    background: Boolean,
    // 每页显示条目个数，支持 .sync 修饰符
    pageSize: Number,
    // 总条目数
    total: Number,
    // 总页数
    pageCount: Number
  },
  data() {
    return {}
  },
  methods: {
    handleSizeChange(size) {
      this.$emit('size-change', size)
    },
    handleCurrentChange(page) {
      this.$emit('current-change', page)
    }
  }
}
</script>
<style scoped lang="scss">
.XWPage {
  height: 30px;
  box-sizing: border-box;
  display: flex;
  justify-content: flex-end;
  background: #fff;
}
</style>

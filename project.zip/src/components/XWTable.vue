<template>
  <div class="XWTable">
    <Table
      ref="table"
      :columns="columnsData"
      :data="tableData || data"
      :loading="loading"
      :height="height - (tableData ? 0 : 25)"
      stripe
      border
      show-header
      highlight-row
      @on-selection-change="handleSelectChange"
    >
      <template v-slot:tool="{row}">
        <slot name="tool" v-bind="row" />
      </template>
      <template v-for="(item,index) in columns">
        <div v-if="item.slot" :key="index" :slot="item.slot">
          <slot :name="`cell${item.slot}`" />
        </div>

        <!-- <div v-if="item.slot" :key="index">
          <XWSlot>
            <template v-slot:name2>
              <div>666</div>
            </template>
          </XWSlot>
        </div>-->
      </template>
    </Table>

    <!-- 分页 -->
    <XWPage
      v-if="!tableData"
      :total="dataTotal"
      @size-change="handleSizeChange"
      @current-change="handleCurrPageChange"
    />
  </div>
</template>

<script>
import XWPage from '@/components/XWPage'
// import Sortable from 'sortablejs'
import { emptyFilter } from '@/filter'
import { layout } from '@/config'
import { deepCopy } from '@/common'
export default {
  name: 'XWTable',
  props: {
    // 表头
    columns: {
      type: Array,
      required: true,
      default: () => []
    },
    // 外部数据
    tableData: Array,
    // 请求方法
    requestMethod: Function,
    // 请求参数
    requestParams: {
      type: Object,
      default: () => {}
    },
    // 是否隐藏序号
    seqHidden: Boolean,
    // 表格内容高度
    height: Number,
    // 最大高度
    maxHeight: [Number, String],
    // 最小列宽
    columnMinWidth: {
      type: [Number, String],
      default: 120
    },
    // 整体对齐方式
    align: {
      type: String,
      default: 'center'
    },
    // 行key 必须
    rowId: String,
    // 是否可选择
    select: {
      type: Boolean,
      default: false
    },
    // 选择方式
    selectType: {
      type: String,
      default: 'multiple'
    },
    // 是否折叠表格
    expand: {
      type: Boolean,
      default: false
    },
    // 是否开启操作选项
    tool: {
      type: Boolean,
      default: false
    },
    // 是否自定义操作表头
    toolHeaderNode: {
      type: Boolean,
      default: false
    },
    // 操作列宽度
    toolWidth: {
      type: [String, Number],
      default: 180
    },
    // 表头行样式类名
    headerRowClassName: String,
    // 合并行或列
    spanMethod: Function,
    // 设置行样式
    rowStyle: [String, Function],
    // 设置单元格样式
    cellStyle: [String, Function]
  },
  components: {
    XWPage
  },

  data() {
    return {
      columnsData: [],
      data: [],
      ...layout,
      // 页数
      pageNo: 1,
      // 每一页条数
      pageSize: 10,
      // 总数
      dataTotal: 0,
      // 加载
      loading: false,
      // 请求参数
      localRequestParams: {},
      visible: false,
      // 选中的值
      selData: []
    }
  },
  computed: {
    localColumns() {
      return this.handleSetLocalColumns(this.columns)
    }
  },
  watch: {
    requestParams: {
      handler(val) {
        this.localRequestParams = val
      },
      deep: true,
      immediate: true
    }
  },
  created() {
    this.init()
  },
  mounted() {
    this.$nextTick(() => {
      this.visible = true
      // this.handleColumnDrop()
    })
  },
  activated() {
    this.$nextTick(() => {
      this.visible = true
      // this.handleColumnDrop()
    })
  },
  deactivated() {
    this.visible = false
  },
  beforeDestroy() {
    if (this.sortable) {
      // this.sortable.destroy()
    }
  },
  methods: {
    // 初始化
    init() {
      // this.columnsData = deepCopy(this.columns)
      this.handleGetRequestData()
      this.handleSetLocalColumns(this.columns)
    },
    // 处理表头
    handleSetLocalColumns(columns) {
      const tempColumns = columns.map(item => ({
        ...item,
        title: item.label,
        key: item.prop,
        width: item.width,
        minWidth: item.minWidth || this.columnMinWidth,
        align: item.align || this.align,
        ellipsis: true,
        resizable: true
      }))
      // 是否可选择
      if (this.select) {
        tempColumns.unshift({
          key: '$select',
          type: 'selection',
          width: 50,
          resizable: true,
          align: 'center'
        })
      }
      // 序号
      if (!this.seqHidden) {
        tempColumns.unshift({
          title: '序号',
          key: '$index',
          type: 'index',
          width: 80,
          resizable: true,
          align: 'center'
        })
      }
      // 操作列
      if (this.tool) {
        tempColumns.push({
          title: '操作',
          key: '$tool',
          width: this.toolWidth,
          resizable: true,
          align: 'center',
          slot: 'tool'
        })
      }

      this.columnsData = tempColumns
    },
    __getParams() {
      const params = deepCopy(this.localRequestParams)
      return {
        page_no: this.pageNo,
        page_size: this.pageSize,
        ...params
      }
    },
    // 获取数据
    handleGetRequestData() {
      if (!this.requestMethod) return
      this.loading = true
      const params = deepCopy(this.localRequestParams)
      this.requestMethod({
        currentPageNum: this.pageNo,
        pageSize: this.pageSize,
        ...params
      })
        .then(res => {
          this.data = res.result || []
          this.loading = false
          this.pageNo = res.comb.curr_total_page || 1
          this.dataTotal = res.comb.total_rec || 0
          console.log('表格数据')
          console.log(this.data)
        })
        .catch(err => {
          this.loading = false
        })
    },
    // 刷新数据
    handleRefresh() {
      this.$nextTick(() => this.handleGetRequestData())
    },
    // 监听每页条数修改
    handleSizeChange(size) {
      this.pageSize = size
      this.handleRefresh()
    },
    // 监听分页页数修改
    handleCurrPageChange(page) {
      this.pageNo = page
      this.handleRefresh()
    },
    // 格式化单元格内容
    handleFormatterCell(args, formatter) {
      const { cellValue, row } = args[1]
      if (!formatter) return cellValue
      const formatterType = typeof formatter
      if (formatterType == 'function') return formatter(cellValue, row)
      if (formatterType == 'string')
        return this.handleSetFormatterCell(formatter, cellValue)
    },
    // 根据formatter类型设置单元格内容
    handleSetFormatterCell(formatter, cellValue) {
      if (cellValue === undefined) return emptyFilter(cellValue)
      if (cellValue === null) return emptyFilter(cellValue)
      switch (formatter) {
        case 'price':
          return `￥ ${cellValue}`
        default:
          return `${formatter} ${cellValue}`
      }
    },
    // 处理单元格内容
    handleSetCellTextNode(scope, col) {
      const { row, column } = scope
      if (!col.formatter) return row[column.property]
      return this.handleFormatterCell(
        [{ cellValue: row[column.property], row: row }],
        col.formatter
      )
    },
    // 单元格点击
    handleCellClick({ row, column, $event: e }) {
      if (!column.property) return
      if (column.type == 'checkbox') return
      if (column.type == 'radio') return
      this.$refs.table.toggleCheckboxRow(row)
    },
    // 监听表格选择
    handleSelectChange(sel) {
      this.selData = sel
    },
    // 获取选中行数据
    getSelections() {
      return this.selData
    },
    __editRender(col, index) {
      const { prop, edit, editConfig, editNodeOptions } = col
      if (edit) {
        if (editConfig) {
          return this.handleEidtRender(prop, editConfig, editNodeOptions, index)
        }
        return { name: 'input', attrs: { type: 'text' } }
      }
      return undefined
    },
    // 监听单元格编辑
    __editActice({ row, column }) {
      if (row[column.property] === undefined) {
        this.$set(row, column.property, '')
      }
      this.$emit('onEditActive')
    },
    // 建通单元格编辑完成
    __editClosed(data) {
      const { row, column } = data
      if (row[column.property]) {
        this.$emit('onEdit', { row, col: column })
      }
    },
    // 单元格编辑按配置渲染
    handleEidtRender(
      prop,
      { type, listKey, precision = 0 },
      nodeOptions,
      index
    ) {
      switch (type) {
        case 'select':
          return { name: '$select', options: selectOptions[listKey].list }
        case 'inputNumber':
          return {
            name: '$input',
            props: { type: 'number', ...nodeOptions }
          }
        default:
          return { name: 'input', attrs: { type: 'text' } }
      }
    },
    // 导出
    __export({ fileName = '导出数据' }) {
      this.$refs.table.exportData({
        filename: fileName,
        sheetName: 'Sheet1',
        type: 'xlsx'
      })
    },
    // // 设置行样式
    // __setRowStyle(){
    //   if(typeof this.rowStyle === 'string'){
    //     return this.rowStyle
    //   }
    //   return this.rowStyle()
    // },
    // 列拖拽
    __setcellStyle(arg) {
      if (this.cellStyle) {
        return this.cellStyle(arg)
      }
    },
    __resizeableChange(obj) {
      console.log(obj)
    },
    handleColumnDrop() {
      this.$nextTick(() => {
        let xTable = this.$refs.table
        this.sortable = Sortable.create(
          xTable.$el.querySelector(
            '.body--wrapper>.vxe-table--header .vxe-header--row'
          ),
          {
            handle: '.vxe-header--column:not(.col--fixed)',
            onEnd: ({ item, newIndex, oldIndex }) => {
              let { fullColumn, tableColumn } = xTable.getTableColumn()
              let targetThElem = item
              let wrapperElem = targetThElem.parentNode
              let newColumn = fullColumn[newIndex]
              if (newColumn.fixed) {
                // 错误的移动
                if (newIndex > oldIndex) {
                  wrapperElem.insertBefore(
                    targetThElem,
                    wrapperElem.children[oldIndex]
                  )
                } else {
                  wrapperElem.insertBefore(
                    wrapperElem.children[oldIndex],
                    targetThElem
                  )
                }
                return this.$XModal.message({
                  message: '固定列不允许拖动！',
                  status: 'error'
                })
              }
              // 转换真实索引
              let oldColumnIndex = xTable.getColumnIndex(tableColumn[oldIndex])
              let newColumnIndex = xTable.getColumnIndex(tableColumn[newIndex])
              // 移动到目标列
              let currRow = fullColumn.splice(oldColumnIndex, 1)[0]
              fullColumn.splice(newColumnIndex, 0, currRow)
              xTable.loadColumn(fullColumn)
            }
          }
        )
      })
    },
    // 判断数组
    _isArray(arr) {
      return arr instanceof Array
    }
  }
}
</script>
<style scoped lang="scss">
::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}

::-webkit-scrollbar-thumb {
  border-radius: 1em;
  background-color: rgba(50, 50, 50, 0.3);
}

::-webkit-scrollbar-track {
  border-radius: 1em;
  background-color: rgba(50, 50, 50, 0.1);
}
.XWTable {
  /deep/ .vxe-table .vxe-cell {
    word-break: normal;
    overflow: hidden;
  }
  /deep/ .vxe-cell--title {
    width: 100%;
  }
  /deep/ .vxe-cell {
    max-height: none !important;
  }

  /deep/ .row--hover,
  /deep/ .row--current {
    background: $themeColor !important;
    .XWTable__tool * {
      color: #fff !important;
    }
  }

  .rowClass {
    // color: #fff !important;
  }
}
</style>

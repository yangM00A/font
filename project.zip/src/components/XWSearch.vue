<template>
  <div class="XWSearch">
    <Form inline :model="data" :label-width="localLabelWidth" ref="searchForm">
      <Row type="flex">
        <Col
          v-for="(item, index) in localFormProps"
          :key="index"
          :span="item.config.span || handleSetDefaultSpan(item.type, 4)"
          :xxl="item.config.span || handleSetDefaultSpan(item.type, 4)"
          :xl="item.config.span || handleSetDefaultSpan(item.type, 6)"
          :lg="item.config.span || handleSetDefaultSpan(item.type, 12)"
          :md="item.config.span || handleSetDefaultSpan(item.type, 12)"
        >
          <FormItem
            :label="item.label"
            :prop="item.prop"
            :label-width="handleSetLabelWidth(item.config.labelWidth)"
          >
            <Input
              :style="{
                Width: handleSetInputWidth(item.config.contentWidth || '100%'),
              }"
              v-if="item.type == 'input'"
              v-model="data[item.prop]"
              size="small"
              :type="item.config.inputType || 'text'"
              :placeholder="handleSetPlaceholder(item)"
              clearable
              :disabled="item.config.disabled"
            ></Input>
            <Select
              :style="{
                width: handleSetInputWidth(item.config.contentWidth || '100%'),
              }"
              v-if="item.type == 'select'"
              v-model="data[item.prop]"
              :disabled="item.config.disabled"
              :multiple="item.config.multiple"
              clearable
              :placeholder="handleSetPlaceholder(item)"
              filterable
              @on-change="handleSelectChange(item.prop, $event)"
            >
              <Option
                v-for="(sel, index) in selectData(
                  selectOptions[item.config.listKey].list
                )"
                :key="index"
                :value="sel.value"
              >{{ sel.label }}</Option>
            </Select>
            <Checkbox
              v-if="item.type == 'checkbox'"
              v-model="data[item.prop]"
              :disabled="item.config.disabled"
              :true-label="item.config.trueLabel || 1"
              :false-label="item.config.falseLabel || 0"
              :border="item.config.border"
            ></Checkbox>
            <DatePicker
              v-if="item.type == 'date'"
              v-model="data[item.prop]"
              :disabled="item.config.disabled"
              clearable
              confirm
              :type="item.config.dateType || 'date'"
              placement="center"
              :format="item.config.dateFormat || 'yyyy-MM-dd HH:mm:ss'"
              :value-format="item.config.dateValFormat || 'yyyy-MM-dd HH:mm:ss'"
              :style="{
                width: handleSetInputWidth(item.config.contentWidth || '100%'),
                maxWidth: '185px',
              }"
              :options="
                item.config.pickerOptions && {
                  shortcuts: handleSetPickerOptions(
                    item.config.dateType,
                    item.config.dateFormat
                  ),
                }
              "
            ></DatePicker>
            <InputNumber
              v-if="item.type == 'inputNumber'"
              v-model="data[item.prop]"
              :style="{
                width: handleSetInputWidth(item.config.contentWidth || '100%'),
              }"
              :min="item.config.min || 0"
              :max="item.config.max"
              :step="item.config.step || 1"
              :precision="item.config.precision"
              :disabled="item.config.disabled"
              :placeholder="handleSetPlaceholder(item)"
              active-change
            ></InputNumber>

            <!-- <template v-if="item.type == 'numberRange'">
              <template v-for="(numProp, numIndex) in item.config.subProps">
                <el-input-number
                  :key="numIndex"
                  :style="{
                    maxWidth: handleSetInputWidth(
                      item.config.numberWidth / 2 || '40%'
                    )
                  }"
                  v-model="data[item.config.subProps[numIndex]]"
                  :min="item.config.min || 0"
                  :max="item.config.max"
                  :step="item.config.step || 1"
                  :precision="item.config.precision"
                  :disabled="item.config.disabled"
                  :controls="false"
                  :placeholder="
                    handleSetPlaceholder({
                      placeholder: item.config.placeholders[numIndex]
                    })
                  "
                ></el-input-number>
                <span v-if="numIndex == 0" :key="numProp">-</span>
              </template>
            </template>-->

            <template v-if="item.type == 'radio'">
              <RadioGroup v-model="data[item.prop]">
                <Radio
                  v-for="(radio, index) in selectOptions[item.config.listKey]
                    .list"
                  :key="index"
                  :label="radio.value"
                >{{ radio.label }}</Radio>
              </RadioGroup>
            </template>

            <!-- 自定义form-item节点 -->
            <slot v-if="item.type == 'node'">
              <slot :name="`node${item.prop}`" />
            </slot>
            <!-- 自定义form-item节点 end -->
          </FormItem>
        </Col>
        <Col :span="4">
          <FormItem>
            <Button size="small" type="primary" @click="handleSearch">查询</Button>
            <Button size="small" type="error" @click="handleFormReset">重置</Button>
          </FormItem>
        </Col>
      </Row>
    </Form>
  </div>
</template>

<script>
import { pickerOptions, rangePickerOptions } from '@/utils/dateOptions'
import { deepCopy } from '@/common'
export default {
  name: 'XWSearch',
  props: {
    // 表单元素
    formProps: {
      type: Array,
      required: true
    },
    // 初始数据
    formData: Object,
    // 全局label宽度
    labelWidth: {
      type: [Number, String],
      default: 'auto'
    },
    // 下拉数据
    selectOptions: Object
  },
  data() {
    return {
      data: {}
    }
  },
  computed: {
    localFormProps: function() {
      return this.handleSetFormPropos(this.formProps)
    },
    localLabelWidth: function() {
      return this.handleSetLabelWidth(this.labelWidth)
    }
  },
  created() {
    this.initData()
  },
  watch: {
    formData() {
      this.initData()
    }
  },
  methods: {
    // 初始化数据
    initData() {
      if (!this.formData) return
      this.data = this.formData
    },
    // 计算新的formprops
    handleSetFormPropos(formProps) {
      return formProps.map(item => {
        let { label, type, prop, placeholder } = item
        type = type || 'input'
        const config = this.handleSetConfig(item.config)
        return {
          label,
          type,
          prop,
          placeholder,
          config
        }
      })
    },
    // 计算labelWidth
    handleSetLabelWidth(val = this.labelWidth) {
      const isNumber = typeof val == 'number' ? true : false
      return isNumber ? val : Number(val)
    },
    // 计算inputWidth
    handleSetInputWidth(val) {
      const isNumber = typeof val == 'number' ? true : false
      return isNumber ? val + 'px' : val
    },
    // 设置占位符
    handleSetPlaceholder(formItem) {
      if (formItem.placeholder) return formItem.placeholder
      return formItem.label
    },
    // 处理每一项的config
    handleSetConfig(config) {
      return config || {}
    },
    // 设置pickerOptions
    handleSetPickerOptions(type = 'date') {
      switch (type) {
        case 'date':
          return pickerOptions
          break
        case 'daterange':
          return rangePickerOptions
        case 'datetimerange':
          return rangePickerOptions
        default:
          return null
      }
    },
    // 重置表单
    handleFormReset() {
      this.$refs.searchForm.resetFields()
      this.data = {}
      this.$emit('reset')
      this.$emit('query', {})
    },
    // 查询
    handleSearch() {
      const [formData, data] = [this.data, {}]
      Object.keys(formData).forEach(key => {
        if (formData[key] === null) return
        if (formData[key] === undefined) return
        if (formData[key] === '') return
        data[key] = formData[key]
      })
      this.$emit('query', data)
    },
    // 处理下拉数据
    selectData(data) {
      return [{ label: '全部', value: '' }].concat(data)
    },
    // col布局设置默认span
    handleSetDefaultSpan(type, def) {
      return def
    },
    // 监听下拉框改变
    handleSelectChange(prop, val) {
      this.$emit('change', { prop, val, data: this.data })
    },
    // 获取数据
    getData() {
      return this.data
    }
  }
}
</script>
<style scoped lang="scss">
.XWSearch {
  padding: 10px 0 0;
  background: #fff;
  /deep/ .el-input__inner {
    text-align: left;
  }
  /deep/ .ivu-form-item {
    width: 100%;
    margin-bottom: 10px;
    .ivu-input-wrapper {
      max-width: 150px;
    }
  }
}
</style>

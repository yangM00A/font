<template>
  <div class="xwLayout">
    <div v-if="isLayout" class="xwLayout_wrap">
      <header class="xwLayout_header">
        <span class="xwLayout_logo">{{ logoTtitle }}</span>
        <span class="xwLayout_loginer">
          <!-- <XWHead trigger="click" hide-on-click :animateTime="200" /> -->
        </span>
      </header>
      <div
        class="xwLayout_container"
        :style="`height:calc(100% - ${headerHeight}px)`"
      >
        <div class="xwLayout_nav">
          <XWNavMenu />
        </div>
        <div class="xw_main" :style="`width:calc(100vw - ${navWidth}px);`">
          <keep-alive>
            <!-- <router-view
              class="xw_main_wrap"
              :style="
                `height:calc(100% - ${crumbHeight}px - ${getScrollWidth}px - 5px)`
              "
            ></router-view> -->
            <router-view
              class="xw_main_wrap"
              :style="`height:calc(100% - ${crumbHeight}px)`"
            />
          </keep-alive>
        </div>
      </div>
    </div>

    <router-view v-else />
  </div>
</template>

<script>
import XWNavMenu from '@/components/XWNavMenu'
import { getScrollWidth } from '@/common'
import { layout } from '@/config'
export default {
  name: 'SWLayout',
  components: { XWNavMenu },
  data() {
    return {
      ...layout,
      getScrollWidth: getScrollWidth(),
      logoTtitle: process.env.VUE_APP_LOGOSTR,
      isLayout: false,
    }
  },
  watch: {
    $route() {
      this.getIsLogin()
    },
  },
  created() {
    this.getIsLogin()
  },
  methods: {
    getIsLogin() {
      const { layout: isLayout } = this.$router.currentRoute.meta
      this.isLayout = isLayout || false
    },
  },
}
</script>
<style scoped lang="scss">
.xwLayout {
  &,
  &_wrap {
    height: 100%;
  }
  &_header {
    height: 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgb(84, 92, 100);
    color: #fff;
    padding: 5px 20px;
    box-sizing: border-box;
  }
  &_logo {
    font-size: 18px;
  }
  &_container {
    display: flex;
    justify-content: space-between;
  }
  .xw_main {
    overflow-y: scroll;
  }
}
</style>

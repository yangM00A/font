<template>
  <Menu class="XWNavMenu" theme="dark">
    <template class="nav_item" v-for="(nav, navIndex) in nav">
      <Submenu v-if="nav.children" :name="String(navIndex)" :key="navIndex">
        <template v-slot:title>
          <i :class="`iconfont ${nav.meta.menuIcon}`"></i>
          <span>{{ nav.meta.title }}</span>
        </template>
        <template v-for="(subNav, subNavIndex) in nav.children">
          <MenuItem
            v-if="!subNav.navHidden"
            :to="{ name: subNav.name }"
            :index="`${nav.navIndex}-${subNav.subNavIndex}`"
            :key="subNavIndex"
            >{{ subNav.meta.title }}</MenuItem
          >
        </template>
      </Submenu>

      <MenuItem
        v-else
        class="el-menu-item"
        :name="nav.path"
        :to="{ name: nav.name }"
        :key="navIndex"
      >
        <template>
          <i :class="`iconfont ${nav.meta.menuIcon}`"></i>
          <span>{{ nav.meta.title }}</span>
        </template>
      </MenuItem>
    </template>
  </Menu>
</template>

<script>
import { color, layout } from '@/config'
export default {
  name: 'XWNavMenu',
  data() {
    return {
      themeColor: color.themeColor,
      ...layout,
      nav: this.$router.app.$options.router.options.routes.filter(
        i => !i.navHidden
      ),
      defaultActive: this.$route.path
    }
  },
  computed: {
    // TODO 临时组装一个菜单列表JSON 用于后端返回数据格式
    navMenu() {
      const temp = this.nav.map(item => {
        let tempItem = {
          name: item.name,
          path: item.path,
          meta: item.meta
        }
        if (item.children) {
          tempItem.children = item.children.map(i => {
            return {
              name: i.name,
              path: i.path,
              meta: i.meta
            }
          })
        }
        return tempItem
      })
      return JSON.stringify(temp)
    }
  },
  watch: {
    $route() {
      this.defaultActive = this.$route.path
    }
  },
  created() {
    console.log(this.$router)
  },
  methods: {
    handleOpen() {},
    handleClose() {}
  }
}
</script>
<style scoped lang="scss">
.XWNavMenu {
  height: 100%;
  overflow-y: scroll;
  .el-submenu__title *,
  .el-menu-item * {
    display: inline-block;
    vertical-align: super;
    margin: 0 5px;
  }
  /deep/ .el-menu-item i,
  /deep/ .el-submenu__title i {
    color: #fff;
  }
  /deep/ .is-active i,
  /deep/ .is-active span {
    color: $themeColor;
  }
}
::-webkit-scrollbar {
  width: 1px;
}
::-webkit-scrollbar-thumb:window-inactive {
  background: rgba(255, 255, 255, 1);
}
</style>

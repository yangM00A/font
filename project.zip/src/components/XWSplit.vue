<template>
  <Split class="XWSplit" v-model="splits">
    <template v-slot:left>
      <div class="XWSplit__container">
        <slot name="left" />
      </div>
    </template>
    <template v-slot:right>
      <div class="XWSplit__container">
        <slot name="right" />
      </div>
    </template>
  </Split>
</template>
<script>
export default {
  props: {
    split: {
      type: Number,
      default: 0.2
    }
  },
  data() {
    return {
      splits: 0
    }
  },
  created() {
    this.splits = this.split
  }
}
</script>
<style lang="scss" scoped>
.XWSplit {
  height: 100%;
  &__container {
    height: 100%;
    padding: 10px;
  }
}
</style>

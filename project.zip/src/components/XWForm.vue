<template>
  <div class="XWForm">
    <Form
      :inline="inline"
      :model="formData"
      :label-width="localLabelWidth"
      :label-position="labelPosition"
      ref="form"
      :rules="rules"
      :inline-message="inlineMessage"
      :disabled="disabled"
    >
      <Row :gutter="10">
        <Col
          class-name="XWForm__col"
          v-for="(item, index) in localFormProps"
          :key="index"
          :span="item.config.span || handleSetDefaultSpan(4)"
          :xxl="item.config.span || handleSetDefaultSpan(4)"
          :xl="item.config.span || handleSetDefaultSpan(6)"
          :lg="item.config.span || handleSetDefaultSpan(12)"
          :md="item.config.span || handleSetDefaultSpan(12)"
        >
          <FormItem
            :label="item.label"
            :prop="item.prop"
            :label-width="handleSetLabelWidth(item.config.labelWidth)"
            :class="inlineMessage ? 'XW-item-inline' : 'XW-item'"
          >
            <Input
              :style="{
                maxWidth: handleSetInputWidth(
                  item.config.contentWidth || '100%'
                ),
                width: handleSetInputWidth(item.config.inputWidth || '100%')
              }"
              v-if="item.type == 'input'"
              v-model="formData[item.prop]"
              :type="item.config.inputType || 'text'"
              :placeholder="handleSetPlaceholder(item)"
              clearable
              :disabled="__disabled(item.config.disabled)"
              :min="item.config.min"
              :max="item.config.max"
            >
              <template v-if="item.config.prepend" v-slot:prepend>
                {{ handleSetInputPrepend(item.config.prepend) }}
              </template>
              <template v-if="item.config.append" v-slot:append>
                {{ handleSetInputPrepend(item.config.append) }}
              </template>
            </Input>
            <Select
              :style="{
                width: handleSetInputWidth(item.config.contentWidth || '100%')
              }"
              v-if="item.type == 'select'"
              v-model="formData[item.prop]"
              :disabled="__disabled(item.config.disabled)"
              :multiple="item.config.multiple"
              clearable
              :placeholder="handleSetPlaceholder(item)"
              filterable
              @on-change="handleSelectChange($event, item)"
            >
              <Option
                v-for="(sel, index) in selectOptions[item.config.listKey].list"
                :key="index"
                :label="sel.label"
                :value="sel.value"
              ></Option>
            </Select>
            <Checkbox
              v-if="item.type == 'checkbox'"
              v-model="formData[item.prop]"
              :disabled="item.config.disabled"
              :true-label="item.config.trueLabel || 1"
              :false-label="item.config.falseLabel || 0"
              :border="item.config.border"
              >{{ item.config.checkboxLabel }}</Checkbox
            >
            <DatePicker
              v-if="item.type == 'date'"
              v-model="formData[item.prop]"
              :disabled="item.config.disabled"
              clearable
              confirm
              :placeholder="handleSetPlaceholder(item)"
              :type="item.config.dateType || 'date'"
              placement="center"
              :format="item.config.dateFormat || 'yyyy-MM-dd HH:mm:ss'"
              :value-format="item.config.dateValFormat || 'yyyy-MM-dd HH:mm:ss'"
              :style="{
                maxWidth: handleSetInputWidth(
                  item.config.contentWidth || '100%'
                ),
                width: handleSetInputWidth(item.config.inputWidth || '100%')
              }"
              :options="
                item.config.pickerOptions && {
                  shortcuts: handleSetPickerOptions(
                    item.config.dateType,
                    item.config.dateFormat
                  )
                }
              "
            ></DatePicker>
            <InputNumber
              v-if="item.type == 'inputNumber'"
              :style="{
                width: handleSetInputWidth(item.config.contentWidth || '100%')
              }"
              v-model="formData[item.prop]"
              :min="item.config.min || item.config.minuns ? item.config.min : 0"
              :max="item.config.max"
              :step="item.config.step || 1"
              :precision="item.config.precision"
              :disabled="item.config.disabled"
              :placeholder="handleSetPlaceholder(item)"
            ></InputNumber>

            <!-- <XWButtonGroup
              v-if="item.type == 'button'"
              :buttons="item.buttons"
            />-->
            <Switch
              v-if="item.type == 'switch'"
              v-model="formData[item.prop]"
              :true-color="item.config.activeColor || '#13ce66'"
              :false-color="item.config.inactiveColor || '#ff4949'"
              :true-value="item.config.trueVal"
              :false-value="item.config.falseVal"
              :disabled="__disabled(item.config.disabled)"
              @on-change="handleSwitchChange"
            ></Switch>

            <RadioGroup
              v-if="item.type == 'radio'"
              v-model="formData[item.prop]"
            >
              <Radio
                v-for="(citem, cindex) in selectOptions[item.config.listKey]
                  .list"
                :key="cindex"
                :label="citem.value"
                :disabled="item.config.disabled"
                border
                >{{ citem.label }}</Radio
              >
            </RadioGroup>

            <CheckboxGroup
              v-if="item.type == 'checkboxGroup'"
              v-model="formData[item.prop]"
            >
              <Checkbox
                v-for="(citem, cindex) in selectOptions[item.config.listKey]
                  .list"
                :label="citem.label"
                :key="cindex"
                :disabled="item.config.disabled"
                border
              ></Checkbox>
            </CheckboxGroup>

            <!-- <Cascader
              v-if="item.type == 'area'"
              :style="{
                maxWidth: handleSetInputWidth(
                  item.config.contentWidth || '100%'
                ),
                width: handleSetInputWidth(item.config.inputWidth || '100%')
              }"
              v-model="formData[item.prop]"
              :props="areaProps"
              clearable
            ></Cascader>-->

            <!-- 自定义form-item节点 -->
            <slot v-if="item.type == 'node'">
              <slot :name="`node${item.prop}`" />
            </slot>
            <!-- 自定义form-item节点 end -->

            <!-- 自定义校验信息 -->
            <!-- <template v-if="inlineMessage" v-slot:error="err">
              <el-tooltip class="item" effect="dark" :content="err.error" placement="top">
                <i class="errorMsg el-icon-warning"></i>
              </el-tooltip>
            </template>-->
            <!-- 自定义校验信息 end -->
          </FormItem>
        </Col>
      </Row>
    </Form>
  </div>
</template>

<script>
// import XWButtonGroup from '@/components/XWButtonGroup'
// import XWEditor from '@/components/XWEditor'
import { pickerOptions, rangePickerOptions } from '@/utils/dateOptions'
export default {
  name: 'XWForm',
  props: {
    // 表单元素
    formProps: {
      type: Array,
      required: true
    },
    // 表单数据
    formData: {
      type: Object,
      default: () => {}
    },
    // 是否行内表单
    inline: {
      type: Boolean,
      default: true
    },
    // 全局label宽度
    labelWidth: {
      type: [Number, String],
      default: 80
    },
    // 表单域标签的位置
    labelPosition: String,
    // 下拉数据
    selectOptions: Object,
    // 验证规则
    rules: Object,
    // 是否以行内形式展示校验信息
    inlineMessage: {
      type: Boolean,
      default: true
    },
    // 是否禁用该表单内的所有组件
    disabled: {
      type: Boolean,
      default: false
    }
  },
  components: {},

  data() {
    return {
      checkboxGroup1: ''
      // areaProps: {
      //   lazy: true,
      //   lazyLoad(node, resolve) {
      //     const { data, level } = node
      //     const pcode = data
      //       ? typeof data.value == 'string'
      //         ? JSON.parse(data.value).ccode
      //         : data.value
      //       : '1'
      //     areas({ pcode: pcode }).then(res => {
      //       const nodes = res.data.map(item => {
      //         item.label = item.area_name
      //         // item.value = JSON.stringify(item)
      //         item.value = JSON.stringify({
      //           ccode: item.ccode,
      //           area_name: item.area_name
      //         })
      //         item.leaf = level >= 2
      //         return item
      //       })
      //       resolve(nodes)
      //     })
      //   }
      // }
    }
  },
  computed: {
    localFormProps() {
      return this.handleSetFormPropos(this.formProps)
    },
    localLabelWidth() {
      return this.handleSetLabelWidth(this.labelWidth)
    }
  },
  created() {},
  methods: {
    // 计算新的formprops
    handleSetFormPropos(formProps) {
      return formProps.map(item => {
        let { label, type, prop } = item
        type = type || 'input'
        const config = this.handleSetConfig(item.config)
        return {
          ...item,
          label,
          type,
          prop,
          config
        }
      })
    },
    // 计算labelWidth
    handleSetLabelWidth(val = this.labelWidth) {
      const isNumber = typeof val == 'number' ? true : false
      return isNumber ? val : Number(val)
    },
    // 计算inputWidth
    handleSetInputWidth(val) {
      const isNumber = typeof val == 'number' ? true : false
      return isNumber ? val + 'px' : val
    },
    // 设置占位符
    handleSetPlaceholder(formItem) {
      if (formItem.placeholder) return formItem.placeholder
      return formItem.label
    },
    // 处理每一项的config
    handleSetConfig(config) {
      return config || {}
    },
    // 设置pickerOptions
    handleSetPickerOptions(type = 'date') {
      switch (type) {
        case 'date':
          return pickerOptions
          break
        case 'daterange':
          return rangePickerOptions
        case 'datetimerange':
          return rangePickerOptions
        default:
          return null
      }
    },
    // 对整个表单进行校验
    handleValidate() {
      return this.$refs.form.validate()
    },
    // 设置复合型输入框内容
    handleSetInputPrepend(prepend) {
      if (typeof prepend == 'function') return prepend()
      return prepend
    },
    // 监听地区选择
    handleAreaChange(val) {},
    // 设置复选框组选中的值
    handleSetCheckboxGroupLabel(item, citem) {
      const { config } = item
      if (config.label === undefined) return citem.value
      return item[config.label]
    },
    // 监听富文本编辑
    handleEditorChange(html, callback) {
      if (!callback) return
      callback(html)
    },
    // col布局设置默认span
    handleSetDefaultSpan(def) {
      return this.inline ? def : 24
    },
    // 是否禁用
    __disabled(disabled) {
      return typeof disabled == 'function' ? disabled() : disabled
    },
    // 监听开关变化
    handleSwitchChange() {
      this.$emit('change', this.formData)
    },
    // 监听下拉变化
    handleSelectChange(value, { prop }) {
      this.$emit('change', { prop, value, data: this.formData })
    }
  }
}
</script>
<style scoped lang="scss">
.XWForm {
  // padding: 10px 0;
  background: #fff;
  // .el-form-item {
  //   margin-bottom: 3px;
  // }
  .XW-item {
    margin-bottom: 20px;
  }
  .XW-item-inline {
    margin-bottom: 3px;
  }
  .el-form--inline {
    margin-right: 0;
  }
  .errorMsg {
    margin-left: 10px;
  }
  /deep/ .el-input__inner {
    text-align: left;
  }
  .ivu-form-item {
    width: 100%;
  }

  &__col {
    margin-bottom: 15px;
  }
}
</style>

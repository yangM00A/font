// import 'babel-polyfill'
import 'core-js/stable'
import 'regenerator-runtime/runtime'

import Vue from 'vue'
import App from '@/App.vue'
import router from '@/router'
import store from '@/store'
import * as filters from '@/filter'
import directives from '@/directivs'
import '@/styles/public.scss'

// 解决ie9下requestAnimationFrame不兼容问题
import requestAnimationFrame from '@/utils/requestAnimationFrame'

requestAnimationFrame()

import ViewUI from 'view-design'
import '@/styles/iview-variables.less'
Vue.use(ViewUI, {
  size: 'default'
})

// 引入iconfont
import '@/assets/iconfont/iconfont.css'

Vue.config.productionTip = false

// 注册全局filter
Object.keys(filters).forEach(name => {
  Vue.filter(name, filters[name])
})

// 注册全局指令
Vue.use(directives)

// 图片预览器
import Viewer from 'v-viewer'
import 'viewerjs/dist/viewer.css'
Vue.use(Viewer, {
  defaultOptions: {
    toolbar: {
      zoomIn: true,
      zoomOut: true,
      prev: true,
      next: true,
      rotateLeft: true,
      rotateRight: true
    },
    zIndex: 9999
  }
})

export default new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

// export default Vue

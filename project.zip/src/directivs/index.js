export default Vue => {
  Vue.directive('test', {})
}

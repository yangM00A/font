// 这里存放正则表达式

// 手机号码
export const regMobile = /^1[3456789]\d{9}$/

import request from '@/utils/request'
import API from '@/config/api'

// 空间管理列表
export const splsSpc = params => {
  return request({
    url: API.splsSpc,
    method: 'get',
    params
  })
}

// 添加空间信息
export const splsScpInsert = params => {
  return request({
    url: API.splsScpInsert,
    method: 'get',
    params
  })
}

// 编辑空间信息
export const splsScpUpdate = params => {
  return request({
    url: API.splsScpUpdate,
    method: 'get',
    params
  })
}

// 删除空间信息
export const splsScpDelete = data => {
  return request({
    url: API.splsScpDelete,
    method: 'detele',
    data
  })
}

// 删除空间信息
export const splsGetEncode = params => {
  return request({
    url: API.splsGetEncode,
    method: 'get',
    params
  })
}

// 删除单位信息
export const splsSpcComp = params => {
  return request({
    url: API.splsSpcComp,
    method: 'get',
    params
  })
}

// 查询空间分组信息
export const splsSpcGroup = params => {
  return request({
    url: API.splsSpcGroup,
    method: 'get',
    params
  })
}

// 编辑空间信息
export const splsScpGroupUpdate = params => {
  return request({
    url: API.splsScpGroupUpdate,
    method: 'get',
    params
  })
}

// 删除空间信息
export const splsScpGroupDelete = data => {
  const { id } = data
  return request({
    url: API.splsScpGroupDelete + '/' + id,
    method: 'delete'
  })
}

// 添加空间信息
export const splsScpGroupInsert = params => {
  return request({
    url: API.splsScpGroupInsert,
    method: 'get',
    params
  })
}

import request from '@/utils/request'
import API from '@/config/api'

// 用户登录接口
export const userLogin = data => {
  return request({
    url: API.userLogin,
    method: 'post',
    data
  })
}

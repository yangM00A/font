import request from '@/utils/request'
import API from '@/config/api'

// 查询资产列表信息
export const splsCgyList = params => {
  return request({
    url: API.splsCgyList,
    method: 'get',
    params
  })
}

// 查询资产分组信息
export const splsCgy = params => {
  return request({
    url: API.splsCgy,
    method: 'get',
    params
  })
}

// 查询资产卡片信息
export const splsCgyDetail = params => {
  const { astId } = params
  return request({
    url: API.splsCgyDetail + '/' + astId,
    method: 'get'
  })
}

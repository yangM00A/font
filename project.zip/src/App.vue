<template>
  <div id="app">
    <XWLayout />
  </div>
</template>

<script>
import XWLayout from '@/components/XWLayout'
export default {
  components: {
    XWLayout
  },
  data() {
    return {}
  }
}
</script>

import Vue from 'vue'
import VueRouter from 'vue-router'
import pages from '@/config/pages'

// 进度条
import NProgress from '@/utils/XWPropgress'
import 'nprogress/nprogress.css'

// 获取用户信息
import { getUserData } from '@/common'

import store from '@/store'

Vue.use(VueRouter)

const routes = [
  {
    path: '/404',
    name: '404',
    component: () => import('@/pages/404/App'),
    navHidden: true,
    meta: { title: '404' }
  },
  {
    path: '/',
    name: 'Home',
    component: () => import('@/pages/Home'),
    navHidden: true,
    meta: { title: '首页', menuIcon: 'iconshouye', layout: true }
  }
]

// 需要权限控制的路由
export const autRoutes = [
  {
    path: '/SpaceManagement',
    name: 'SpaceManagement',
    component: pages.SpaceManagement.component,
    meta: { ...pages.SpaceManagement.meta }
  },
  {
    path: '/AssetsParameter',
    name: 'AssetsParameter',
    component: pages.AssetsParameter.component,
    meta: { ...pages.AssetsParameter.meta }
  }
]

const router = new VueRouter({
  //routes,
  routes: [...routes, ...autRoutes]
})

// 重定向404白名单
const whiteList = ['404', 'Home']

router.beforeEach(async (to, from, next) => {
  const userData = getUserData()
  // 处理404
  if (!to.matched.length) {
    const patharr = to.path.split('/')
    const name = patharr[1]
    if (pages[name] === undefined) return next({ name: '404' })
  }

  NProgress.start()
  next()
})

router.afterEach((to, from) => {
  NProgress.done()
})

export default router

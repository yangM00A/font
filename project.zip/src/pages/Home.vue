<template>
  <div>
    <h2>欢迎进入后台管理系统！！</h2>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },
}
</script>
<style scoped lang="scss"></style>

import Vue from '@/main'
import App from './App.vue'

new Vue({
  el: '#AssetsParameter',
  render: h => h(App)
})

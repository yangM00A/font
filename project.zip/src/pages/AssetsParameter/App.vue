<template>
  <div class="AssetsParameter">
    <XWSplit>
      <template v-slot:left>
        <div class="AssetsParameter__classSearch">
          <Input />
          <Button type="primary" @click="handleClassSearch">查询</Button>
        </div>
        <Tree :data="groupData" @on-select-change="handleTreeChange"></Tree>
      </template>
      <template v-slot:right>
        <XWSearch class="AssetsParameter__search" :formProps="searchProps" @query="handleSearch" />
        <XWTable
          ref="table"
          :columns="table.columns"
          :requestMethod="getSplsCgyList"
          :requestParams="table.params"
          :height="tableHeight"
          tool
        >
          <template v-slot:tool>
            <Button type="text" @click="handleAddAccessories">添加配件</Button>
          </template>
        </XWTable>
      </template>
    </XWSplit>

    <!-- 查看弹出层 -->
    <XWDialog
      :width="moreDialog.width"
      :title="moreDialog.title"
      :visible.sync="moreDialog.visible"
      @upadte="handleMoreDialogUpdate"
      @confirm="handleMoreDialogConfirm"
    >
      <div class="AssetsParameter__more__wrap">
        <div class="list">
          <span>卡片编号</span>
          <ul>
            <li
              :class="item.$active ? 'active' : ''"
              v-for="(item,index) in moreDialog.list"
              :key="index"
              @click="handleSetMoreInfo(index)"
            >{{item.crdId}}</li>
          </ul>
        </div>
        <div class="info" v-if="moreDialog.list.length">
          <div class="info__item">类别名称：{{moreDialog.currInfo.astCgyEcd | emptyFilter}}</div>
          <div class="info__item">存放地点：{{moreDialog.currInfo.strgLo | emptyFilter}}</div>
          <div class="info__item">资产名称：{{moreDialog.currInfo.names | emptyFilter}}</div>
          <div class="info__item">详细地址：{{moreDialog.currInfo.detailLocation | emptyFilter}}</div>
          <div class="info__item">卡片编号：{{moreDialog.currInfo.crdId | emptyFilter}}</div>
          <div class="info__item">合同编号：{{moreDialog.currInfo.ctrId | emptyFilter}}</div>
          <div class="info__item">资产归口管理部门：{{moreDialog.currInfo.bsnMngdAdmndepyId | emptyFilter}}</div>
          <div class="info__item">保修期限：{{moreDialog.currInfo.prsvDdln | emptyFilter}}</div>
          <div class="info__item">资产用途：{{moreDialog.currInfo.astPrps | emptyFilter}}</div>
          <div class="info__item">验收日期：{{moreDialog.currInfo.chkandacptDt | emptyFilter}}</div>
          <div class="info__item">供应商名称：</div>
          <div class="info__item">报废日期：{{moreDialog.currInfo.scrpDt | emptyFilter}}</div>
          <div class="info__item">生产厂商名称：</div>
          <div class="info__item">维保起始日期：{{moreDialog.currInfo.mntncStDt | emptyFilter}}</div>
          <div class="info__item">序列号：{{moreDialog.currInfo.srlNo | emptyFilter}}</div>
          <div class="info__item">维保截止日期：{{moreDialog.currInfo.mntncCoDt | emptyFilter}}</div>
          <div class="info__item">到货日期：{{moreDialog.currInfo.splsCreateDate | emptyFilter}}</div>
          <div class="info__item">维保合同编号：{{moreDialog.currInfo.mntncCtrId | emptyFilter}}</div>
          <div class="info__item">关键程度：{{moreDialog.currInfo.crtclDgr | emptyFilter}}</div>
          <div class="info__item">业务归口管理部门：{{moreDialog.currInfo.bsnMngdAdmndepyId | emptyFilter}}</div>
          <div class="info__item">是否业务延伸设备：</div>
          <div class="info__item">闲置原因：</div>
          <div class="info__item">业务延伸牵头部门：{{moreDialog.currInfo.bsnLeadExtdInstId | emptyFilter}}</div>
          <div class="info__item">父资产卡片编号：{{moreDialog.currInfo.prnAstCrdId | emptyFilter}}</div>
          <div class="info__item">强制报废年限：{{moreDialog.currInfo.enfrcScrpYrlmt | emptyFilter}}</div>
          <div class="info__item">借用人：{{moreDialog.currInfo.brwEmpId | emptyFilter}}</div>
          <div class="info__item">使用部门：{{moreDialog.currInfo.brwDeptId | emptyFilter}}</div>
          <div class="info__item">借用机构：</div>
          <div class="info__item">责任中心：{{moreDialog.currInfo.rspcntId | emptyFilter}}</div>
          <div class="info__item">配置性能：{{moreDialog.currInfo.conproperty | emptyFilter}}</div>
          <div class="info__item">资产卡片状态：{{moreDialog.currInfo.splsCrdst | emptyFilter}}</div>
          <div class="info__item">规格信息：</div>
          <div
            class="info__item info__item__block"
          >资产使用状态：{{moreDialog.currInfo.astUsSt | emptyFilter}}</div>
          <div class="info__item info__item__block">使用类型：{{moreDialog.currInfo.usTp | emptyFilter}}</div>
          <div
            class="info__item info__item__block"
          >使用人：{{moreDialog.currInfo.usEmpId | emptyFilter}}</div>
          <div
            class="info__item info__item__block"
          >维护人：{{moreDialog.currInfo.maintenanceempId | emptyFilter}}</div>
          <div
            class="info__item info__item__block"
          >责任人：{{moreDialog.currInfo.rsplempId | emptyFilter}}</div>
          <div class="info__item info__item__block">【邮件信息】：</div>
        </div>
      </div>
    </XWDialog>
    <!-- 查看弹出层 end -->

    <!--添加配件弹出层 -->
    <XWDialog
      :width="addAccessoriesDialog.width"
      :title="addAccessoriesDialog.title"
      :isButton="true"
      :visible.sync="addAccessoriesDialog.visible"
      @upadte="handleAddAccessoriesDialogUpdate"
    >
      <div class="AssetsParameter__addSearch__wrap">
        <div class="AssetsParameter__addSearch">
          <Input placeholder="编码/名称" v-model="addAccessoriesDialog.searchText" />
          <Button type="primary">查询</Button>
        </div>
        <div>
          <Button>批量删除</Button>
          <Button @click="handleSelAccessories">添加配件</Button>
        </div>
      </div>
      <XWTable
        :columns="addAccessoriesDialog.columns"
        :tableData="table.data"
        :height="400"
        seqHidden
        tool
        select
      >
        <template v-slot:tool>
          <Button type="text">删除</Button>
        </template>
      </XWTable>
    </XWDialog>
    <!--添加配件弹出层 end -->

    <!--添加配件列表弹出层 -->
    <XWDialog
      :width="addAccessoriesListDialog.width"
      :title="addAccessoriesListDialog.title"
      :visible.sync="addAccessoriesListDialog.visible"
      :zindex="1001"
      @upadte="handleAddAccessoriesListDialogUpdate"
      @confirm="handleAddAccessoriesListDialogConfirm"
    >
      <XWSplit class="addAccessoriesList__slpit">
        <template v-slot:left>
          <Tree :data="addAccessoriesListDialog.classlist"></Tree>
        </template>
        <template v-slot:right>
          <div class="AssetsParameter__addSearch__wrap">
            <div class="AssetsParameter__addSearch">
              <Input placeholder="编码/名称" v-model="addAccessoriesDialog.searchText" />
              <Button type="primary">查询</Button>
            </div>
            <div>
              <Checkbox v-model="addAccessoriesDialog.isAll">显示全部配件</Checkbox>
            </div>
          </div>
          <XWTable
            :columns="addAccessoriesDialog.columns"
            :tableData="table.data"
            :height="250"
            seqHidden
            tool
            select
          >
            <template v-slot:tool>
              <Button type="text">删除</Button>
            </template>
          </XWTable>
        </template>
      </XWSplit>
    </XWDialog>
    <!--添加配件列表弹出层 end -->
  </div>
</template>
<script>
import XWSplit from '@/components/XWSplit'
import XWSearch from '@/components/XWSearch'
import XWTable from '@/components/XWTable'
import XWDialog from '@/components/XWDialog'
import { splsCgyList, splsCgy, splsCgyDetail } from '@/api/AssetsParameter'
import { setTableContent } from '@/common'
export default {
  components: { XWSearch, XWTable, XWSplit, XWDialog },
  data() {
    return {
      tableHeight: 300,
      groupData: [
        {
          title: '全部',
          expand: true,
          children: [
            { title: '汽车' },
            { title: '空调' },
            { title: '消防设施' },
            { title: '办公设施' },
            { title: '其他设施' }
          ]
        }
      ],
      searchProps: [{ label: '资产名称', prop: 'names' }],
      table: {
        columns: [
          {
            label: '卡片详情',
            prop: 'boAdmndeptViInd',
            render: (h, params) =>
              h(
                'Button',
                {
                  props: { type: 'text' },
                  on: {
                    click: () => this.handleMore(params)
                  }
                },
                '查看'
              )
          },
          { label: '资产编号', prop: 'encode' },
          { label: '资产名称', prop: 'names' },
          { label: '厂商', prop: 'mftrName' },
          { label: '品牌', prop: 'brndName' },
          { label: '型号', prop: 'modlName' },
          { label: '规格', prop: 'params' },
          { label: '管理部门', prop: 'manageDef' },
          { label: '状态', prop: 'status' }
        ],
        data: [{ name: '测试数据' }],
        params: {}
      },
      // 查看弹出层
      moreDialog: {
        width: 685,
        title: '查看',
        visible: false,
        list: [],
        currInfo: {}
      },
      // 添加配件弹出层
      addAccessoriesDialog: {
        width: 690,
        title: '已添加配件',
        visible: false,
        searchText: '',
        columns: [
          { label: '名称', prop: 'a' },
          { label: '编码', prop: 'a' },
          { label: '品牌', prop: 'a' },
          { label: '型号', prop: 'a' }
        ]
      },
      // 添加配件弹出层
      addAccessoriesListDialog: {
        width: 690,
        title: '添加配件',
        visible: false,
        classlist: [
          {
            title: '非固定资产',
            expand: true,
            children: [
              { title: '空调配件' },
              {
                title: '汽车配件',
                expand: true,
                children: [{ title: '发动机' }, { title: '刹车片' }]
              }
            ]
          },
          {
            title: '固定资产'
          },
          {
            title: '其他资产'
          }
        ],
        searchText: '',
        isAll: false,
        columns: [
          { label: '名称', prop: 'a' },
          { label: '编码', prop: 'a' },
          { label: '品牌', prop: 'a' },
          { label: '型号', prop: 'a' }
        ]
      }
    }
  },
  created() {
    this.init()
  },
  mounted() {
    this.handleSetTableHeight()
    window.addEventListener('resize', () => {
      this.handleSetTableHeight()
    })
  },
  methods: {
    init() {
      this.getSplsCgy()
    },
    // 设置表格高度
    handleSetTableHeight() {
      setTableContent(tableHeight => {
        this.tableHeight = tableHeight
      })
    },
    handleClassSearch() {},
    getSplsCgyList: splsCgyList,
    // 获取资产分组
    getSplsCgy() {
      splsCgy().then(res => {
        this.groupData = res.map(item => ({ ...item, title: item.astCgy }))
      })
    },
    handleSearch(data) {
      const { cgyEcd } = this.table.params
      this.table.params = { ...data, cgyEcd }
      this.$refs.table.handleRefresh()
    },
    handleTreeChange(data) {
      data = data[0]
      this.table.params.cgyEcd = data.cgyEcd
      this.$refs.table.handleRefresh()
    },
    // 查看
    handleMore({ row }) {
      const { astId, names } = row
      splsCgyDetail({ astId }).then(res => {
        if (res.success) {
          let temp = res || []
          if (res.length) {
            temp = temp.map(item => ({ ...item, names }))
            temp[0].$active = true
            this.moreDialog.currInfo = temp[0]
          }
          this.moreDialog.list = temp
        }
      })
      this.moreDialog.visible = true
    },
    handleMoreDialogUpdate(v) {
      this.moreDialog.visible = v
    },
    handleMoreDialogConfirm() {},
    // 动态设置卡片内容
    handleSetMoreInfo(index) {
      this.moreDialog.list.forEach(item => {
        item.$active = false
      })
      this.moreDialog.list[index].$active = true
      this.moreDialog.currInfo = this.moreDialog.list[index]
    },
    // 已添加配件
    handleAddAccessories() {
      this.addAccessoriesDialog.visible = true
    },
    handleAddAccessoriesDialogUpdate(v) {
      this.addAccessoriesDialog.visible = v
    },
    handleSelAccessories() {
      this.addAccessoriesListDialog.visible = true
    },
    handleAddAccessoriesListDialogUpdate(v) {
      this.addAccessoriesListDialog.visible = v
    },
    handleAddAccessoriesListDialogConfirm() {}
  }
}
</script>
<style lang="scss" scoped>
.AssetsParameter {
  height: 100vh;
  &__classSearch {
    display: flex;
    align-items: center;
  }
  &__more__wrap {
    display: flex;
    .list {
      width: 165px;
      height: 680px;
    }
    .info {
      width: calc(100% - 165px);
      box-sizing: border-box;
      padding: 10px;
    }
    .list span {
      display: block;
      line-height: 40px;
      text-align: center;
      background: #ccc;
    }
    .list ul li {
      line-height: 30px;
      border: 1px solid #ccc;
      border-top: 0;
      padding: 5px;
      cursor: pointer;
    }
    .list ul .active {
      background: $themeColor;
    }
    .info__item {
      display: inline-block;
      width: 50%;
    }
    .info__item__block {
      width: 100%;
    }
  }
}
.AssetsParameter__addSearch__wrap {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}
.AssetsParameter__addSearch {
  display: flex;
}
.addAccessoriesList__slpit {
  height: 300px;
}
</style>

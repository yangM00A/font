<template>
  <div class="Web404"></div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>
<style scoped lang="scss">
.Web404 {
  width: 100%;
  height: 100%;
  background: url(~@/assets/images/404.png) no-repeat 100% 100%;
}
</style>

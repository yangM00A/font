<template>
  <div class="SpaceManagement">
    <XWSplit>
      <template v-slot:left>
        <div class="SpaceManagement__classSearch">
          <Input v-model="groupSearchStr" />
          <Button type="primary" @click="handleClassSearch">查询</Button>
        </div>
        <Tree
          :render="renderContent"
          :data="groupData"
          @on-select-change="handleTreeChange"
        ></Tree>
      </template>
      <template v-slot:right>
        <div class="SpaceManagement__searchWrap">
          <XWSearch
            class="SpaceManagement__search"
            :formProps="searchProps"
            @query="handleSearch"
          />
          <Button @click="handleAdd">新增</Button>
        </div>
        <XWTable
          ref="table"
          :columns="table.columns"
          :tableData="table.data"
          :requestMethod="getSplsSpc"
          :requestParams="table.params"
          :height="tableHeight"
          tool
        >
          <template v-slot:tool="row">
            <Button type="text" @click="handleEdit(row)">编辑</Button>
            <Button type="text" @click="handleDel(row)">删除</Button>
          </template>
        </XWTable>
      </template>
    </XWSplit>

    <!-- 编辑弹出层 -->
    <XWDialog
      :width="eidtDialog.width"
      :title="eidtDialog.title"
      :visible.sync="eidtDialog.visible"
      @upadte="handleEditDialogUpdate"
      @confirm="handleEditDialogConfirm"
    >
      <XWForm
        v-if="eidtDialog.visible"
        ref="form"
        :formProps="eidtDialog.formProps"
        :formData="eidtDialog.data"
        :labelWidth="100"
        :rules="eidtDialog.rules"
        :selectOptions="selectOptions"
        inline
        @change="handleEditFormChange"
      />
    </XWDialog>
  </div>
</template>
<script>
import XWSplit from '@/components/XWSplit'
import XWSearch from '@/components/XWSearch'
import XWTable from '@/components/XWTable'
import XWDialog from '@/components/XWDialog'
import XWForm from '@/components/XWForm'
import {
  splsSpc,
  splsScpInsert,
  splsScpUpdate,
  splsScpDelete,
  splsGetEncode,
  splsSpcComp,
  splsSpcGroup,
  splsScpGroupUpdate,
  splsScpGroupDelete,
  splsScpGroupInsert
} from '@/api/SpaceManagement'
import { setTableContent, downloadFile } from '@/common'
import QRCode from 'qrcodejs2'
export default {
  components: { XWSearch, XWTable, XWSplit, XWDialog, XWForm },
  data() {
    return {
      tableHeight: 300,
      groupSearchStr: '',
      groupData: [
        {
          title: '全部',
          expand: true,
          children: [
            { title: 'A楼', id: 1 },
            { title: 'B楼' },
            { title: 'C楼' },
            { title: 'D楼' },
            { title: 'A区室外' }
          ]
        }
      ],
      searchProps: [
        { label: '空间编码', prop: 'encode' },
        { label: '空间名称', prop: 'name' }
      ],
      table: {
        columns: [
          { label: '空间编码', prop: 'encode' },
          { label: '空间名称', prop: 'name' },
          { label: '空间地址', prop: 'address' },
          { label: '面积（㎡）', prop: 'square' },
          { label: '空间类型', prop: 'spcType' },
          {
            label: '二维码',
            prop: 'names',
            render: (h, params) =>
              h(
                'Button',
                {
                  props: { type: 'text' },
                  on: {
                    click: () => this.handleCode(params)
                  }
                },
                '二维码'
              )
          }
        ],
        data: [{ name: '测试数据' }],
        params: {}
      },
      eidtDialog: {
        width: 750,
        title: '',
        visible: false,
        formProps: [
          {
            prop: 'encode',
            label: '空间编码',
            config: { span: 12, disabled: true }
          },
          { prop: 'name', label: '空间名称', config: { span: 12 } },
          { prop: 'address', label: '空间地址', config: { span: 24 } },
          { prop: 'square', label: '面积(㎡)', config: { span: 24 } },
          {
            prop: 'spcType',
            label: '空间类型',
            type: 'select',
            config: { span: 12, listKey: 'spcType' }
          },
          {
            prop: 'propertyDef',
            label: '产权单位',
            type: 'select',
            config: { span: 12, listKey: 'def' }
          },
          {
            prop: 'managerDef',
            label: '管理单位',
            type: 'select',
            config: { span: 12, listKey: 'def' }
          },
          {
            prop: 'usePropertyDef',
            label: '使用权单位',
            type: 'select',
            config: { span: 12, listKey: 'def' }
          },
          {
            prop: 'useDef',
            label: '使用单位',
            type: 'select',
            config: { span: 12, listKey: 'def' }
          },
          {
            prop: 'status',
            label: '使用状态',
            type: 'select',
            config: { span: 12, listKey: 'status' }
          },
          { prop: 'useSpc', label: '空间用途', config: { span: 12 } },
          {
            prop: 'comments',
            label: '备注',
            config: { span: 24, inputType: 'textarea' }
          }
        ],
        data: {},
        rules: {
          encode: { required: true, message: '请输入空间名称' },
          name: { required: true, message: '请输入空间地址' },
          address: { required: true, message: '请输入面积' },
          square: { required: true, message: '请输入空间类型' },
          spc_type: { required: true, message: '请输入产权单位' }
        }
      },
      buttonProps: {
        type: 'default',
        size: 'small'
      },
      selectOptions: {
        // 空间类型
        spcType: {
          list: [
            { label: '公共区域', value: 'GGQY' },
            { label: '办公室', value: 'BGS' },
            { label: '会议室', value: 'HYS' },
            { label: '洗手间', value: 'XSJ' }
          ]
        },
        // 使用状态
        status: {
          list: [
            { label: '不可用', value: 0 },
            { label: '可用', value: 1 }
          ]
        },
        // 单位列表
        def: {
          list: []
        }
      }
    }
  },
  created() {
    this.init()
  },
  mounted() {
    this.handleSetTableHeight()
    window.addEventListener('resize', () => {
      this.handleSetTableHeight()
    })
  },
  methods: {
    init() {
      this.getSplsSpcGroup()
    },
    // 获取单位列表
    getSplsSpcComp() {
      splsSpcComp({ currPageNum: 1, pageSize: 1000 }).then(res => {
        this.selectOptions.def.list =
          res.result.map(item => ({
            label: item.compName,
            value: item.compId
          })) || []
      })
    },
    // 获取空间分组列表
    getSplsSpcGroup(name) {
      // const test = [
      //   { id: 1, parents: 0, title: '一级' },
      //   { id: 2, parents: 0, title: '一级a' },
      //   { id: 3, parents: 1, title: '一级-二级' },
      //   { id: 4, parents: 2, title: '一级a-二级' },
      //   { id: 5, parents: 3, title: '一级-二级-三级' }
      // ]
      // const parents = test.filter(item => !item.parents)
      // const childrens = test.filter(item => item.parents)
      // this.groupData = parents.map(item => ({ ...item, children: [] }))
      // this.handleSplsSpcGroup(childrens)
      // return
      splsSpcGroup(name ? { name } : {}).then(res => {
        let data = res || []
        data = data.map(item => ({ ...item, title: item.name }))
        if (!data.length) return
        const parents = data.filter(item => !item.parents)
        const childrens = data.filter(item => item.parents)
        this.groupData = parents.map(item => ({ ...item, children: [] }))
        this.handleSplsSpcGroup(childrens)
      })
    },
    // 计算出正确的空间分组树
    handleSplsSpcGroup(childrens, parent = this.groupData) {
      if (!childrens.length) return
      let currChildrens = []
      parent.forEach(item => {
        currChildrens.push(...childrens.filter(i => i.parents == item.id))
        item.children = childrens.filter(i => i.parents == item.id)
      })
      const otherChildren = childrens.filter(
        i => !parent.find(i2 => i2.id == i.parents)
      )
      // 如果有剩余未处理完，递归调用
      if (otherChildren.length) {
        this.handleSplsSpcGroup(otherChildren, currChildrens)
      }
    },
    // 设置表格高度
    handleSetTableHeight() {
      setTableContent(tableHeight => {
        this.tableHeight = tableHeight
      })
    },
    renderContent(h, { root, node, data }) {
      return h(
        'span',
        {
          style: {
            display: 'inline-block',
            width: '100%'
          }
        },
        [
          h('span', [
            data.$edit
              ? h('Input', {
                  props: {
                    value: data.title,
                    size: 'small'
                  },
                  style: { width: '100px' },
                  on: {
                    'on-change': e => {
                      data.title = e.target.value
                      data.name = e.target.value
                    },
                    'on-blur': () => {
                      this.$set(data, '$edit', false)
                      this.handleEditSplsSpcGroup(data)
                    }
                  }
                })
              : h('span', data.title)
          ]),
          h(
            'span',
            {
              style: {
                display: 'inline-block',
                float: 'right',
                marginRight: '32px'
              }
            },
            [
              h('Button', {
                props: Object.assign({}, this.buttonProps, {
                  icon: 'ios-add'
                }),
                style: {
                  marginLeft: '8px'
                },
                on: {
                  click: () => {
                    this.append(data)
                  }
                }
              }),
              h('Button', {
                props: Object.assign({}, this.buttonProps, {
                  icon: 'ios-create-outline'
                }),
                style: {
                  marginLeft: '8px'
                },
                on: {
                  click: () => {
                    this.classEdit(data)
                  }
                }
              }),
              h('Button', {
                props: Object.assign({}, this.buttonProps, {
                  icon: 'ios-remove'
                }),
                style: {
                  marginLeft: '8px'
                },
                on: {
                  click: () => {
                    this.remove(root, node, data)
                  }
                }
              })
            ]
          )
        ]
      )
    },
    handleSearch(data) {
      const { catalogNo } = this.table.params
      this.table.params = { ...data, catalogNo }
      this.$refs.table.handleRefresh()
    },
    handleTreeChange(data) {
      data = data[0]
      this.table.params.catalogNo = data.id
      this.$refs.table.handleRefresh()
    },
    append(data) {
      const children = data.children || []
      splsScpGroupInsert({
        name: '未命名',
        parents: data.id,
        type: 0,
        status: 1
      }).then(res => {
        if (res.success) {
          this.getSplsSpcGroup()
          // children.push({
          //   title: '未命名',
          //   expand: true
          // })
          // this.$set(data, 'children', children)
        }
      })
    },
    remove(root, node, data) {
      this.$Modal.confirm({
        title: '提示',
        content: '是否确认删除？',
        onOk: () => {
          splsScpGroupDelete({ id: data.id }).then(res => {
            if (res.success) {
              this.$Message.success('操作成功')
              this.getSplsSpcGroup()
            }
          })
        }
      })
      // const parentKey = root.find(el => el === node).parent
      // const parent = root.find(el => el.nodeKey === parentKey).node
      // const index = parent.children.indexOf(data)
      // parent.children.splice(index, 1)
    },
    classEdit(data) {
      this.$set(data, '$edit', !data.$edit)
    },
    // 失焦修改分组数据
    handleEditSplsSpcGroup(data) {
      console.log(data)
      splsScpGroupUpdate(data).then(res => {
        if (res.success) {
          this.$Message.success('操作成功')
        }
      })
    },
    handleClassSearch() {
      if (!this.groupSearchStr) return this.$Message.warning('请输入名称')
      this.getSplsSpcGroup(this.groupSearchStr)
    },
    getSplsSpc: splsSpc,
    // 新增
    handleAdd() {
      this.eidtDialog.data = {}
      this.eidtDialog.title = '新增'
      this.eidtDialog.visible = true
    },
    // 编辑
    handleEdit(row) {
      this.eidtDialog.title = '编辑'
      this.eidtDialog.data = row
      this.eidtDialog.visible = true
    },
    handleEditDialogUpdate(v) {
      this.eidtDialog.visible = v
    },
    // 新增编辑确认
    handleEditDialogConfirm() {
      this.$refs.form.handleValidate().then(res => {
        if (!res) return
        if (this.eidtDialog.title == '新增') {
          splsScpInsert(this.eidtDialog.data).then(res => {
            this.$Message.success('操作成功')
            this.eidtDialog.visible = false
          })
        } else {
          splsScpUpdate(this.eidtDialog.data).then(res => {
            this.$Message.success('操作成功')
            this.eidtDialog.visible = false
          })
        }
      })
    },
    //删除
    handleDel({ spcId }) {
      this.$Modal.confirm({
        title: '提示',
        content: '是否确认删除？',
        onOk: () => {
          splsScpDelete({ spcId }).then(res => {
            if (res.success) {
              this.$Message.success('操作成功')
            }
          })
        }
      })
    },
    // 监听新增修改表单改变
    handleEditFormChange({ prop, value }) {
      console.log(value)

      // 监听空间类型变化
      if (prop == 'spc_type') {
        splsGetEncode({ spcType: value }).then(res => {
          this.$set(this.eidtDialog.data, 'encode', res)
        })
      }
    },
    // 二维码
    handleCode({ row }) {
      const { encode } = row
      this.$Modal.confirm({
        okText: '导出二维码',
        render: h => {
          return h(
            'div',
            {
              attrs: { id: 'qrcode' },
              style: {
                display: 'flex',
                justifyContent: 'center'
              }
            },
            ''
          )
        },
        onOk: () => {
          const url = document
            .getElementById('qrcode')
            .getElementsByTagName('img')[0]
            .getAttribute('src')
          downloadFile(url)
        }
      })
      this.$nextTick(() => {
        let qrcode = new QRCode('qrcode', {
          width: 200,
          height: 200,
          text: encode || '没有编码数据',
          foreground: '#333',
          render: 'canvas'
        })
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.SpaceManagement {
  &__searchWrap {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  &__classSearch {
    display: flex;
    align-items: center;
  }
  &__search {
    width: 100%;
  }
  height: 100vh;
  &__container {
    padding: 10px;
  }
}
</style>

// import Login from '@/pages/Login/App'
import SpaceManagement from '@/pages/SpaceManagement/App'
import AssetsParameter from '@/pages/AssetsParameter/App'

export default {
  // Login: {
  //   component: Login,
  //   meta: {
  //     title: '登录'
  //   }
  // },
  SpaceManagement: {
    component: SpaceManagement,
    meta: {
      title: '空间管理',
      menuIcon: 'icondianpu'
    }
  },
  AssetsParameter: {
    component: AssetsParameter,
    meta: {
      title: '资产台账',
      menuIcon: 'icondianpu'
    }
  }
}

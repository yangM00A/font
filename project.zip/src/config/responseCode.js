// 这里存放接口返回状态吗
export default {
  200: {
    success: true,
    msg: 'OK'
  },
  201: {
    success: false,
    msg: 'Created'
  },
  401: {
    success: false,
    msg: 'Unauthorized'
  },
  401: {
    success: false,
    msg: 'Forbidden'
  },
  404: {
    success: false,
    msg: 'Not Found'
  }
}

export const layout = {
  // 头部高度
  headerHeight: 50,
  // 导航宽度
  navWidth: 160,
  // 面包屑高度
  crumbHeight: 35
}

export const color = {
  // 主题颜色
  themeColor: '#fa8072'
}

// 字典
export const dict = {
  // 用户状态
  user_state: 'user_state',
  // 银行
  sys_bank: 'sys_bank',
  // 任务状态
  tasks_sate: 'task_state',
  // 任务子类型
  sub_task_type: 'sub_task_type'
}

// 图片服务器地址
export const imageBaseUrl = 'http://dev.gzkxun.com'

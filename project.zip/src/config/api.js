export default {
  // 空间管理列表
  splsSpc: 'splsSpc',
  // 添加空间信息
  splsScpInsert: 'splsSpcInsert',
  // 编辑空间信息
  splsScpUpdate: 'splsSpcUpdate',
  // 删除空间信息
  splsScpDelete: 'splsSpcDelete',
  // 获取空间编码
  splsGetEncode: 'splsGetEncode',
  // 获取单位列表
  splsSpcComp: 'splsSpcComp',
  // 查询空间分组信息
  splsSpcGroup: 'splsSpcGroup',
  // 编辑空间信息
  splsScpGroupUpdate: 'splsSpcGroupUpdate',
  // 删除空间信息
  splsScpGroupDelete: 'splsSpcGroupDelete',
  // 添加空间信息
  splsScpGroupInsert: 'splsSpcGroupInsert',
  // 查询资产列表信息
  splsCgyList: 'splsCgyList',
  // 查询资产分组信息
  splsCgy: 'splsCgy',
  // 查询资产分组信息
  splsCgyDetail: 'splsCgyDetail'
}

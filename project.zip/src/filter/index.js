export const emptyFilter = (val, str = '--') => {
  switch (typeof val) {
    case 'string':
      if (val.trim() !== '') return val
      break
    case 'number':
      return val
  }
  return str
}

export const prependFilter = (val, str, emptyFilterStr = '--') => {
  return val === emptyFilterStr ? val : `${str}${val}`
}
export const appendFilter = (val, str, emptyFilterStr = '--') => {
  return val === emptyFilterStr ? val : `${val}${str}`
}

// 深拷贝
export const deepCopy = obj => {
  return JSON.parse(JSON.stringify(obj))
}

import JsEncrypt from 'jsencrypt'
// rsa加密
export const rsaEncrypt = val => {
  const rsa = new JsEncrypt()
  rsa.setPublicKey(
    'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCOUKWHGovExODRESL/2cOfcbpofbc54fgNp9xKQigLWpTUA/i0/DfnBTTwC5Neo10fuTNfrXEeWcbq+GTHZdOf2Jypb3J1SAuf7Kirf4WDaUJag5lKDBXNkhBP63Jg2oFVBgxzgRfL+zFzBJmHYd64n9ZT8sFi0D4oUJaK1TO94QIDAQAB'
  )
  return rsa.encrypt(val)
}

import randomstring from 'string-random'
// 生成随机字符串
export const randomString = (num = 10) => {
  return randomstring(num)
}

// 获取用户信息
export const getUserData = () => {
  const userData = window.localStorage.getItem('userData')
  return userData ? JSON.parse(userData) : null
}

// 获取滚动条宽度
export const getScrollWidth = () => {
  var noScroll,
    scroll,
    oDiv = document.createElement('DIV')
  oDiv.style.cssText =
    'position:absolute; top:-1000px; width:100px; height:100px; overflow:hidden;'
  noScroll = document.body.appendChild(oDiv).clientWidth
  oDiv.style.overflowY = 'scroll'
  scroll = oDiv.clientWidth
  document.body.removeChild(oDiv)
  return noScroll - scroll
}

// 获取所有兄弟节点
const getChildrenNode = e => {
  var subs = [] //保存所有兄弟节点
  var childrens = e.parentNode.children //获取父级的所有子节点
  Array.from(childrens).forEach(item => {
    if (item.nodeType == 1 && item != e) {
      //如果该节点是元素节点与不是这个节点本身
      subs.push(item) // 添加到兄弟节点里
    }
  })
  return subs
}

// 动态设置表格内容高度
export const setTableContent = callback => {
  const e = document.getElementsByClassName('XWTable')[0]
  const otherHeight = getChildrenNode(e)
    .map(item => item.offsetHeight)
    .reduce((p, n) => p + n, 0)
  e.style.height = `calc(100% - ${otherHeight}px)`
  callback && callback(e.offsetHeight)
}

export const downloadFile = (url, fileName = '无名称') => {
  if (!url) return
  const link = document.createElement('a')
  link.style.display = 'none'
  link.href = url
  link.setAttribute('download', fileName)
  document.body.appendChild(link)
  link.click()
}

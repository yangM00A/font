import DayJs from 'dayjs'

export const pickerOptions = {
  shortcuts: [
    {
      text: '今天',
      onClick(picker) {
        picker.$emit(
          'pick',
          DayJs()
            .set('h', 0)
            .set('m', 0)
            .set('s', 0)
            .format('YYYY-MM-D HH:mm:ss')
        )
      }
    },
    {
      text: '7天前',
      onClick(picker) {
        picker.$emit(
          'pick',
          DayJs()
            .subtract(7, 'd')
            .set('h', 0)
            .set('m', 0)
            .set('s', 0)
            .format('YYYY-MM-D HH:mm:ss')
        )
      }
    },
    {
      text: '30天前',
      onClick(picker) {
        picker.$emit(
          'pick',
          DayJs()
            .subtract(30, 'd')
            .set('h', 0)
            .set('m', 0)
            .set('s', 0)
            .format('YYYY-MM-D HH:mm:ss')
        )
      }
    }
  ]
}

export const rangePickerOptions = {
  shortcuts: [
    {
      text: '今天',
      onClick(picker) {
        const start = DayJs()
          .set('h', 0)
          .set('m', 0)
          .set('s', 0)
          .format('YYYY-MM-D HH:mm:ss')
        const end = DayJs()
          .set('h', 23)
          .set('m', 59)
          .set('s', 59)
          .format('YYYY-MM-D HH:mm:ss')
        picker.$emit('pick', [start, end])
      }
    },
    {
      text: '近7日',
      onClick(picker) {
        const end = DayJs()
          .set('h', 23)
          .set('m', 59)
          .set('s', 59)
          .format('YYYY-MM-D HH:mm:ss')
        const start = DayJs()
          .subtract(7, 'd')
          .set('h', 0)
          .set('m', 0)
          .set('s', 0)
          .format('YYYY-MM-D HH:mm:ss')
        picker.$emit('pick', [start, end])
      }
    },
    {
      text: '近30日',
      onClick(picker) {
        const end = DayJs()
          .set('h', 23)
          .set('m', 59)
          .set('s', 59)
          .format('YYYY-MM-D HH:mm:ss')
        const start = DayJs()
          .subtract(30, 'd')
          .set('h', 0)
          .set('m', 0)
          .set('s', 0)
          .format('YYYY-MM-D HH:mm:ss')
        picker.$emit('pick', [start, end])
      }
    },
    {
      text: '近3个月',
      onClick(picker) {
        const end = DayJs()
          .set('h', 23)
          .set('m', 59)
          .set('s', 59)
          .format('YYYY-MM-D HH:mm:ss')
        const start = DayJs()
          .subtract(3, 'month')
          .set('h', 0)
          .set('m', 0)
          .set('s', 0)
          .format('YYYY-MM-D HH:mm:ss')
        picker.$emit('pick', [start, end])
      }
    }
  ]
}

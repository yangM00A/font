import axios from 'axios'
import Vue from '@/main'
import resCode from '@/config/responseCode'
// 获取用户信息
// import { getUserData } from '@/common'

// console.log(Qs)

const request = axios.create({
  baseURL: process.env.VUE_APP_API_URL
})

let AssessToken = ''

// request拦截器
request.interceptors.request.use(
  config => {
    const { method } = config
    // 判断是否是formdata对象
    const isFormData =
      Object.prototype.toString.call(config.data) === '[object FormData]'
    const _data = isFormData ? config.data : { ...config.data }

    // 打印请求参数
    // console.log('---------请求参数---------')
    // console.log(JSON.stringify(_data))

    // 处理get请求数据
    // if (method == 'get') {
    //   config.params = Qs.stringify(config.params)
    // }
    config.data = _data
    config.headers.Accept = '*/*'
    // config.headers['Content-Type'] =
    //   method == 'get' ? 'application/x-www-form-urlencoded' : 'application/json'
    config.headers['Content-Type'] = 'application/json'

    // const userData = getUserData()
    // if (userData) {
    //   AssessToken = userData.token
    // }
    // config.headers['x-auth-token'] = AssessToken

    return config
  },
  error => {
    Promise.reject(error)
  }
)
// respone拦截器
request.interceptors.response.use(
  response => {
    const res = response.data
    console.log('请求工具输出')
    console.log(response)
    console.log(res)
    if (response.status == 200) {
      const type = Object.prototype.toString.call(res)
      if (type.indexOf('Object') > -1) {
        res.success = true
      }
      return res
    } else {
      // 处理token无效
      // if (res.code == 509 || res.code == 508) {
      //   window.localStorage.removeItem('userData')
      //   Vue.$router.replace({ name: 'Login' })
      // }
      // res.success = false
      // Vue.$Message.warning(res.msg)
      // return Promise.reject(res)
    }
  },
  error => {
    Vue.$Message.warning('服务器出错')
    return Promise.reject(error)
  }
)

export default request
